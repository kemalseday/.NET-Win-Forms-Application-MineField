﻿namespace MineField
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblTitle = new System.Windows.Forms.Label();
            this.groupBoxParameters = new System.Windows.Forms.GroupBox();
            this.numericUpDownRemainingTime = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownNumberMines = new System.Windows.Forms.NumericUpDown();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblNumberMines = new System.Windows.Forms.Label();
            this.lblRemainingTime = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblArmstrongResult = new System.Windows.Forms.Label();
            this.btnFind = new System.Windows.Forms.Button();
            this.listBoxNumber = new System.Windows.Forms.ListBox();
            this.txtUpperLimit = new System.Windows.Forms.TextBox();
            this.txtLowerLimit = new System.Windows.Forms.TextBox();
            this.lblTitleUpperLimit = new System.Windows.Forms.Label();
            this.lblTitleLowerLimit = new System.Windows.Forms.Label();
            this.lblTitleNumber = new System.Windows.Forms.Label();
            this.lblTitle2 = new System.Windows.Forms.Label();
            this.pnlButtons = new System.Windows.Forms.FlowLayoutPanel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBoxParameters.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownRemainingTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNumberMines)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTitle.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.lblTitle.Location = new System.Drawing.Point(12, 27);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(310, 42);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "SORU 1 :";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBoxParameters
            // 
            this.groupBoxParameters.Controls.Add(this.numericUpDownRemainingTime);
            this.groupBoxParameters.Controls.Add(this.numericUpDownNumberMines);
            this.groupBoxParameters.Controls.Add(this.lblTime);
            this.groupBoxParameters.Controls.Add(this.lblNumberMines);
            this.groupBoxParameters.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBoxParameters.Location = new System.Drawing.Point(12, 398);
            this.groupBoxParameters.Name = "groupBoxParameters";
            this.groupBoxParameters.Size = new System.Drawing.Size(310, 100);
            this.groupBoxParameters.TabIndex = 2;
            this.groupBoxParameters.TabStop = false;
            this.groupBoxParameters.Text = "Parametreler";
            // 
            // numericUpDownRemainingTime
            // 
            this.numericUpDownRemainingTime.Location = new System.Drawing.Point(167, 66);
            this.numericUpDownRemainingTime.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownRemainingTime.Name = "numericUpDownRemainingTime";
            this.numericUpDownRemainingTime.Size = new System.Drawing.Size(137, 22);
            this.numericUpDownRemainingTime.TabIndex = 3;
            this.numericUpDownRemainingTime.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numericUpDownNumberMines
            // 
            this.numericUpDownNumberMines.Location = new System.Drawing.Point(167, 28);
            this.numericUpDownNumberMines.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.numericUpDownNumberMines.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownNumberMines.Name = "numericUpDownNumberMines";
            this.numericUpDownNumberMines.Size = new System.Drawing.Size(137, 22);
            this.numericUpDownNumberMines.TabIndex = 2;
            this.numericUpDownNumberMines.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTime.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTime.Location = new System.Drawing.Point(16, 66);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(121, 22);
            this.lblTime.TabIndex = 1;
            this.lblTime.Text = "     Süre (sn) =";
            // 
            // lblNumberMines
            // 
            this.lblNumberMines.AutoSize = true;
            this.lblNumberMines.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNumberMines.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblNumberMines.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblNumberMines.Location = new System.Drawing.Point(16, 28);
            this.lblNumberMines.Name = "lblNumberMines";
            this.lblNumberMines.Size = new System.Drawing.Size(120, 22);
            this.lblNumberMines.TabIndex = 0;
            this.lblNumberMines.Text = "Mayın Sayısı =";
            // 
            // lblRemainingTime
            // 
            this.lblRemainingTime.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblRemainingTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRemainingTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblRemainingTime.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblRemainingTime.Location = new System.Drawing.Point(12, 512);
            this.lblRemainingTime.Name = "lblRemainingTime";
            this.lblRemainingTime.Size = new System.Drawing.Size(182, 35);
            this.lblRemainingTime.TabIndex = 3;
            this.lblRemainingTime.Text = "Kalan Süre = __";
            this.lblRemainingTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnStart.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnStart.Location = new System.Drawing.Point(230, 512);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(92, 35);
            this.btnStart.TabIndex = 4;
            this.btnStart.Text = "Başla";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.lblArmstrongResult);
            this.panel1.Controls.Add(this.btnFind);
            this.panel1.Controls.Add(this.listBoxNumber);
            this.panel1.Controls.Add(this.txtUpperLimit);
            this.panel1.Controls.Add(this.txtLowerLimit);
            this.panel1.Controls.Add(this.lblTitleUpperLimit);
            this.panel1.Controls.Add(this.lblTitleLowerLimit);
            this.panel1.Controls.Add(this.lblTitleNumber);
            this.panel1.Controls.Add(this.lblTitle2);
            this.panel1.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel1.Location = new System.Drawing.Point(341, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(288, 584);
            this.panel1.TabIndex = 5;
            // 
            // lblArmstrongResult
            // 
            this.lblArmstrongResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblArmstrongResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblArmstrongResult.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblArmstrongResult.Location = new System.Drawing.Point(30, 478);
            this.lblArmstrongResult.Name = "lblArmstrongResult";
            this.lblArmstrongResult.Size = new System.Drawing.Size(220, 86);
            this.lblArmstrongResult.TabIndex = 9;
            this.lblArmstrongResult.Text = "Armstrong Sayısı";
            this.lblArmstrongResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnFind
            // 
            this.btnFind.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnFind.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnFind.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnFind.Location = new System.Drawing.Point(180, 411);
            this.btnFind.Name = "btnFind";
            this.btnFind.Size = new System.Drawing.Size(70, 35);
            this.btnFind.TabIndex = 8;
            this.btnFind.Text = "Bul";
            this.btnFind.UseVisualStyleBackColor = false;
            this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
            // 
            // listBoxNumber
            // 
            this.listBoxNumber.FormattingEnabled = true;
            this.listBoxNumber.ItemHeight = 16;
            this.listBoxNumber.Location = new System.Drawing.Point(30, 250);
            this.listBoxNumber.Name = "listBoxNumber";
            this.listBoxNumber.Size = new System.Drawing.Size(134, 196);
            this.listBoxNumber.TabIndex = 7;
            // 
            // txtUpperLimit
            // 
            this.txtUpperLimit.Location = new System.Drawing.Point(157, 200);
            this.txtUpperLimit.Name = "txtUpperLimit";
            this.txtUpperLimit.Size = new System.Drawing.Size(93, 22);
            this.txtUpperLimit.TabIndex = 6;
            this.txtUpperLimit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUpperLimit_KeyPress);
            // 
            // txtLowerLimit
            // 
            this.txtLowerLimit.Location = new System.Drawing.Point(30, 200);
            this.txtLowerLimit.Name = "txtLowerLimit";
            this.txtLowerLimit.Size = new System.Drawing.Size(93, 22);
            this.txtLowerLimit.TabIndex = 5;
            this.txtLowerLimit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLowerLimit_KeyPress);
            // 
            // lblTitleUpperLimit
            // 
            this.lblTitleUpperLimit.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lblTitleUpperLimit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTitleUpperLimit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTitleUpperLimit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTitleUpperLimit.Location = new System.Drawing.Point(157, 152);
            this.lblTitleUpperLimit.Name = "lblTitleUpperLimit";
            this.lblTitleUpperLimit.Size = new System.Drawing.Size(93, 29);
            this.lblTitleUpperLimit.TabIndex = 4;
            this.lblTitleUpperLimit.Text = "Üst Sınır";
            this.lblTitleUpperLimit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTitleLowerLimit
            // 
            this.lblTitleLowerLimit.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lblTitleLowerLimit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTitleLowerLimit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTitleLowerLimit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTitleLowerLimit.Location = new System.Drawing.Point(30, 152);
            this.lblTitleLowerLimit.Name = "lblTitleLowerLimit";
            this.lblTitleLowerLimit.Size = new System.Drawing.Size(93, 29);
            this.lblTitleLowerLimit.TabIndex = 3;
            this.lblTitleLowerLimit.Text = "Alt Sınır";
            this.lblTitleLowerLimit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTitleNumber
            // 
            this.lblTitleNumber.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lblTitleNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTitleNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTitleNumber.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTitleNumber.Location = new System.Drawing.Point(30, 105);
            this.lblTitleNumber.Name = "lblTitleNumber";
            this.lblTitleNumber.Size = new System.Drawing.Size(220, 29);
            this.lblTitleNumber.TabIndex = 2;
            this.lblTitleNumber.Text = "- SAYI -";
            this.lblTitleNumber.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTitle2
            // 
            this.lblTitle2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblTitle2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTitle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTitle2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblTitle2.Location = new System.Drawing.Point(30, 25);
            this.lblTitle2.Name = "lblTitle2";
            this.lblTitle2.Size = new System.Drawing.Size(220, 42);
            this.lblTitle2.TabIndex = 1;
            this.lblTitle2.Text = "SORU 2 :";
            this.lblTitle2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlButtons
            // 
            this.pnlButtons.BackColor = System.Drawing.Color.NavajoWhite;
            this.pnlButtons.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlButtons.Location = new System.Drawing.Point(12, 91);
            this.pnlButtons.Name = "pnlButtons";
            this.pnlButtons.Size = new System.Drawing.Size(310, 289);
            this.pnlButtons.TabIndex = 6;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(622, 580);
            this.Controls.Add(this.pnlButtons);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.lblRemainingTime);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.groupBoxParameters);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vize";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBoxParameters.ResumeLayout(false);
            this.groupBoxParameters.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownRemainingTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownNumberMines)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.GroupBox groupBoxParameters;
        private System.Windows.Forms.NumericUpDown numericUpDownRemainingTime;
        private System.Windows.Forms.NumericUpDown numericUpDownNumberMines;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Label lblNumberMines;
        private System.Windows.Forms.Label lblRemainingTime;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblArmstrongResult;
        private System.Windows.Forms.Button btnFind;
        private System.Windows.Forms.ListBox listBoxNumber;
        private System.Windows.Forms.TextBox txtUpperLimit;
        private System.Windows.Forms.TextBox txtLowerLimit;
        private System.Windows.Forms.Label lblTitleUpperLimit;
        private System.Windows.Forms.Label lblTitleLowerLimit;
        private System.Windows.Forms.Label lblTitleNumber;
        private System.Windows.Forms.Label lblTitle2;
        private System.Windows.Forms.FlowLayoutPanel pnlButtons;
        private System.Windows.Forms.Timer timer1;
    }
}

