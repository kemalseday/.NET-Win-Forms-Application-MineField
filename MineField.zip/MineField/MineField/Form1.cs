﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MineField
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int counter;
        private void btnStart_Click(object sender, EventArgs e)
        {
            FillMine(Convert.ToInt32( numericUpDownNumberMines.Value));
            counter = Convert.ToInt32(numericUpDownRemainingTime.Value);
            timer1.Enabled = true;
        }
        void  FillMine(int mine)
        {
            pnlButtons.Controls.Clear();
            int[] mines = new int[mine];
            Random rnd = new Random();
            for (int i = 0; i < mine; i++)
            {
                int selectedMine= rnd.Next(0, 25);

                if (mines.Contains(selectedMine))
                {
                    i--;
                    continue;
                }
                mines[i] = selectedMine;
            }
            for (int i = 0; i < 25; i++)
            {
                Button btn = new Button();
                btn.Width = 40;
                btn.Height = 40;
                btn.BackColor = Color.DimGray;
                btn.Tag = mines.Contains(i);
                btn.Click += btn_Click;
                pnlButtons.Controls.Add(btn);
            }

        }
        void FinishGame()
        {
            foreach (Button item in pnlButtons.Controls)
            {
                bool state = (bool)item.Tag;
                if(state)
                {
                    item.BackColor = Color.Red;
                    
                }
                else
                {
                    item.BackColor = Color.Green;
                }
            }
           DialogResult result=MessageBox.Show("Oyun Bitti Yeniden Oynamak İstermisiniz?","Uyarı",MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                FillMine(Convert.ToInt32(numericUpDownNumberMines.Value));
                counter = Convert.ToInt32(numericUpDownRemainingTime.Value);
                timer1.Enabled = true;
            }
                
            else
            {
                numericUpDownNumberMines.Value = 1;
                numericUpDownRemainingTime.Value = 1;
                pnlButtons.Controls.Clear();
                lblRemainingTime.Text = "Kalan Süre = __";
            }
                
        }

        private void btn_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            Button clicked = (Button)sender;
            bool state = (bool)clicked.Tag;
            if(state==true)
            {
                clicked.BackColor = Color.Red;
                FinishGame();

            }
            else
            {
                clicked.BackColor = Color.Green;
            }
            counter= Convert.ToInt32(numericUpDownRemainingTime.Value);
            timer1.Enabled = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Interval = 1000;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(counter==0)
            {
                timer1.Enabled = false;
                FinishGame();
                
            }
            else
            lblRemainingTime.Text = "Kalan Süre = " +counter--;


        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            for (int i =Convert.ToInt32(txtLowerLimit.Text); i <= Convert.ToInt32(txtUpperLimit.Text); i++)
            {
                int a = i / 100;
                int b = (i - a * 100) / 10;
                int c = (i - a * 100 - b * 10);

                int d = a * a * a + b * b * b + c * c * c;

                if (i == d)
                    listBoxNumber.Items.Add(i.ToString());
                   
            }
        }

        private void txtLowerLimit_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtUpperLimit_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
    }
}
